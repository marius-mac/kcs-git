// =================Patikrinimas ar veikia==========================
console.log(" ");
console.log(" ");

// =================paleidziamas js tik uzkrovus html (js pradzia)==
$ (document).ready(function(){

// =================Patikrinimas ar veikia js========================

document.querySelector("h2").innerHTML += " ";
document.querySelector("h2").innerHTML += "<br>" + " ";
// =================Patikrinimas ar veikia jquery====================
$ ("h2").css("color", "red");


// =================2-jQ-efects=====================================



// ================js pabaiga=======================================
});
